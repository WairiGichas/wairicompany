# Task 18: Using Python or PHP or Java or Ruby or JavaScript
# Continue with the same program and calculate an individual’s Net Salary using:
#  net_salary = gross_salary - (nhif + nssf + payee)

# Write a normal program but use functions if you feel comfortable.