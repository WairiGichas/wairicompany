# TechCamp Africa20:16
# name = '  JOHn  .' # to “john”
# stripped_name = name.strip()
# sliced_stripped_name = stripped_name[0:4]
# lower_sliced_stripped_name = sliced_stripped_name.lower()
# # print(lower_sliced_stripped_name)

# sentence_one = 'The Dog Breed is German Shepherd' #only display “Breed is German”
# print(sentence_one[8:23])

# sentence_two = 'Defeats for the Clinton forces, this was her moment of triumph' # only display “Clinton forces”
# print(sentence_two[16:30])



