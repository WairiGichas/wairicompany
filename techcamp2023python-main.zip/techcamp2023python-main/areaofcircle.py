#print("my name is mwalimu")
# x =  input("What is your name ")
# print("The name of the new user is ", x)

# x = 12
# y= 20

# z= x+y 
# print(z)


# my_pi = 22 / 7 
# print (my_pi)

# radius = 20

# area_of_circle = my_pi * radius * radius 
# print(area_of_circle)

# name = input("Enter your name")
# print ("Hello" +" "+ name)
 
# r = input("Enter the Radius: ")
# pi = 3.14
# area_of_a_circle = pi * int(r) * int(r)
# print(area_of_a_circle)

ou