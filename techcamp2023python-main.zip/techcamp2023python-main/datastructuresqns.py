ls1=["Mombasa", ["Kitale", ("Eldoret", "Fill"),("Nakuru")]]
# Replace Fill with Machakos
# temp =list (ls1 [1][1])
# temp [1] = "Machakos"
# temp = tuple(temp)
# ls1[1][1]=temp
print (ls1)

# taskList[4] =list(taskList[4])
# taskList[4][1]='Jane'
# taskList[4] = tuple(taskList[4])
# print(taskList[4])



#Expected output should be


#["Mombasa", ["Kitale", ("Eldoret", "Machakos"),("Nakuru")]]
