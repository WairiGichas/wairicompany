def calc():
    #process/task
    total = 50 + 40
    # to return info
    return total

calc()
