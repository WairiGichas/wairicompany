#trainees = ["John", [2, ["James","Mary"]]]
# 1. Display 2 using index, from the list
#print(trainees[1][0])

#2. Output Jame using index, from the list
#print(trainees[1][1][0])


#print(trainees[1][1][1])
#print(trainees[1][1][0])
#trainees[1]=56
#print(trainees[1])
#trainees = ('trainees[1]',[1],' +'mike.'+'[1]')
