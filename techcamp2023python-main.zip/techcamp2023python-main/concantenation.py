# # platform_password =" Wairimu   "
# # # stripped_platform_password = platform_password.strip()
# # # print (platform_password)

# # # count_of_s = platform_password.count(i)
# # # print (count_of_s)

# # #string concantination
# # # firstname = "Esther"
# # # secondname = "wairimu"
# # # fullname =firstname + ' ' + secondname
# # # print(fullname)

# # # class number to send a message basing on the phone numbers
# # class_number = '254722444999'
# # sliced_class_number =class_number[3:12] 


# # full_class_number ='0' + sliced_class_number
# # #or
# # # full_class_number str(0) +sliced_class_number
# # #zero_to_add ="0"

# # #or
# # #full_class_number= zero_to_add + sliced_class_number
# # print (full_class_number)


# # no_to_add =input("Enter interger-specific prefix:  ")
# # cust_no= no_to_add + sliced_class_number
# # print(cust_no))

# #spliting
# class_number = '254722444999'
# sliced_class_number =class_number[3:12:2]

# sliced_class_number =class_number[::-1] #printing backwards- finding paridrops words like poop
# print (sliced_class_number)

