name="  JOHn ,"
a= name.lower()
b= a.strip()
print(b)

