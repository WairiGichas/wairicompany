# TASK 1: Using Python or PHP or Java or Ruby or JavaScript
# Write a program that prompts the user to enter the base and height of a triangle and returns its area.
# Once you learn functions,revisit this and write this code inside a function.

b = input("Enter the base: ") 
h = input("Enter the height: ")
k=0.5
area_of_triangle =float(k)*int(b)*int(h)
print(area_of_triangle)

