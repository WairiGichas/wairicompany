person = {"location" : "Nairobi" , "countries" : ["Kenya", "Turkey"]}
print(person)
# print(person.values())
# print(person.items())