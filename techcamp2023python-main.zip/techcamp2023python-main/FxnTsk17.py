# TASK 17: Using Python or PHP or Java or Ruby or JavaScript
# To calculate the Employees Payee, you need to find the gross salary first then find the taxable income (this is the gross salary less the NHIF value) 

# i.e taxable_income = gross salary - NSSF

# Continue with the same program and find the person's PAYEE .

# Find the Kenya PAYEE Tax Rate using THIS LINK
# Once you learn functions,revisit this and write this code inside a function.

