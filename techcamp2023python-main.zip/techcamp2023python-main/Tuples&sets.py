# #days = ("monday","tuesday","wednesday","thursday", "friday","saturday","sunday")
# #1. Find wednesday using an index
# #print(days[2])

# #2. Using a function a find the length of the tuple.
# #print(len(days))

# #3. Replace Thursday with Thur
# # days =list(days)
# # days[3]= "Thur"
# # days =tuple (days)
# # print (days)

# #SET
# days = {"monday","tuesday","wednesday","thursday", "friday","saturday","sunday","sunday","sunday","sunday"}
# #print(days)
# #print(days[1])
# print(sorted(days))

# # Removing friday and sunday from the set using methods.
# # days =list(days)
# # days.remove('friday')
# # days.remove('sunday')
# # days = set(days)
# # print(days)

# #appending friday and sunday
# # days =list(days)
# # days.append('friday')
# # days.append('sunday')
# # days = set(days)
# # print(days)


# # #or
# # days.remove("friday")
# # days.remove("sunday")

# # days.add("friday")
# # days.add("sunday")
